import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserService } from '../services/user.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-friend-list',
  templateUrl: './friend-list.component.html',
  styleUrls: ['./friend-list.component.css']
})
export class FriendListComponent implements OnInit {
  users:User[];
  user:User;
  successMessage:string
  errorMessage:string
  userId:number


  constructor(private router:Router, private userService:UserService,private route:ActivatedRoute ) { }

  ngOnInit() {
    this.user=JSON.parse(localStorage.getItem("user"));
    this.userId = this.user.userId;
    this.userService.getMyFriends(this.userId).subscribe(
      tempUsers=>{
        this.users=tempUsers;
      },
      error=>{
        this.errorMessage=error;
      }
    )
  }

}