import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import {ActivatedRoute,Router} from '@angular/router';
import { User } from '../user';

@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})
export class LoginUserComponent implements OnInit {

  pageTitle1:string="Already a user?"
  pageTitle2:string="Sign in here"
  errorMessage:string
  _emailId:string
  _password:string

  constructor(private router:Router,private userService : UserService) { }

  ngOnInit() {
  }

  get emailId():string{
    return this._emailId
  }
  
  set emailId(value:string){
    this._emailId=value
  }

  get password():string{
    return this._password
  }

  set password(value:string){
    this._password=value
  }

  onClick(){
    this.userService.loginUser(this._emailId, this._password).subscribe(
      user=>{
        localStorage.setItem('user', JSON.stringify(user))
        this.router.navigate(['/wall'])
      },
      error=>{
        console.error('Error Segment')
      }
    )
   
    
  }
}