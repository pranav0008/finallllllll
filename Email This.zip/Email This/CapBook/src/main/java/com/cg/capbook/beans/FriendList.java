package com.cg.capbook.beans;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name="seq1", initialValue=1, allocationSize=100)
public class FriendList {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq1")
	private int id1;
	private int friendId;
	@ManyToOne
	@JoinColumn(name="userId")
	private User user;
	public FriendList(int friendId, User user) {
		super();
		this.friendId = friendId;
		this.user = user;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + friendId;
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FriendList other = (FriendList) obj;
		if (friendId != other.friendId)
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}

	public int getFriendId() {
		return friendId;
	}

	public void setFriendId(int friendId) {
		this.friendId = friendId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "FriendList [friendId=" + friendId + ", user=" + user + "]";
	}

	public FriendList() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
