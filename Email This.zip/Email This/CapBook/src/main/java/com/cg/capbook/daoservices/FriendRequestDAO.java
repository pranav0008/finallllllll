package com.cg.capbook.daoservices;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import com.cg.capbook.beans.FriendRequest;

public interface FriendRequestDAO extends JpaRepository<FriendRequest,Integer>{

	@Transactional
	@Modifying
	@Query(value="INSERT INTO Friend_Request(request_id,user_id) VALUES(?1,?2)",nativeQuery=true)
	int getRequest(int userIdSender, int userIdreceiver);

	
	@Transactional
	@Modifying
	@Query("DELETE FROM FriendRequest a WHERE a.requestId=:userIdSender and a.user.userId=:userIdreceiver")
	int removeReceivedRequest(@Param("userIdSender")int userIdSender, @Param("userIdreceiver") int userIdreceiver);
}