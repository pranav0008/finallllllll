package com.cg.capbook.services;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.capbook.beans.FriendList;
import com.cg.capbook.beans.FriendRequest;
import com.cg.capbook.beans.Messages;
import com.cg.capbook.beans.SentRequest;
import com.cg.capbook.beans.User;
import com.cg.capbook.daoservices.FriendListDAO;
import com.cg.capbook.daoservices.FriendRequestDAO;
import com.cg.capbook.daoservices.MessageDAO;
import com.cg.capbook.daoservices.SentRequestDAO;
import com.cg.capbook.daoservices.UserDAO;
import com.cg.capbook.exceptions.IncorrectPasswordException;
import com.cg.capbook.exceptions.RequestAlreadySentException;
import com.cg.capbook.exceptions.SameUserIdException;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.sun.jna.platform.win32.Sspi.TimeStamp;

import oracle.sql.TIMESTAMP;

@Component(value="userServices")
public class UserServicesImpl implements UserServices{
	
	int flag=0;
	int i=0;
	int j=0;
	
	@Autowired
	UserDAO userDao;
	@Autowired
	FriendListDAO friendListDao;
	@Autowired
	FriendRequestDAO friendRequestDao;
	@Autowired
	SentRequestDAO sentRequestDao;
	@Autowired
	MessageDAO messageDao;
	
	private Messages message;
	private FriendRequest friendRequest;
	private FriendList friendList;
	private User user;
	private SentRequest sentRequest;
	@Override
	public User registerUser(User user) {
		return userDao.save(user);
	}
	@Override
	public boolean userExists(User user) {
		return (userDao.findByEmail(user.getEmailId())!=null);
	}
	@Override
	public User getUserDetails(int userId) throws UserDetailsNotFoundException {
		return userDao.findById(userId).orElseThrow(()->
		new UserDetailsNotFoundException("user details are not found"));		
	}
	@Override
	public User editUserDetails(User user) {
		return userDao.save(user);
	}
	@Override
	public boolean deleteUserAccount(int userId) throws UserDetailsNotFoundException {
		userDao.findById(userId).orElseThrow(()->
		new UserDetailsNotFoundException("user details are not found"));
		userDao.deleteById(userId);
		return true;
	}
	@Override
	public List<User> getAllUserDetails() {
		return userDao.findAll();
	}
	@Override
	public User loginUser(String emailId, String password) throws IncorrectPasswordException, UserDetailsNotFoundException {
		User user = userDao.findByEmail(emailId);
		/*if(user==null)
			throw new UserDetailsNotFoundException("");
		else {
			if(password.equals(user.getPassword()))
				return user;
			else
				throw new IncorrectPasswordException("Incorrect password");
		}*/
		if(password.equals(user.getPassword()))
			return user;
		else
			throw new IncorrectPasswordException("Incorrect password");
	}
	@Override
	public User getUserId(String emailId) {
		return userDao.findByEmail(emailId);
	}
	@Override
	public boolean rejectRequest(int userIdSender, int userIdreceiver) throws UserDetailsNotFoundException {
		userDao.findById(userIdSender).orElseThrow(()->
		new UserDetailsNotFoundException("sender user details not found"));
		userDao.findById(userIdreceiver).orElseThrow(()->
		new UserDetailsNotFoundException("receiver user details not found"));
		friendRequestDao.removeReceivedRequest(userIdSender, userIdreceiver);
		sentRequestDao.cancelRequestSent(userIdSender, userIdreceiver);
		return false;
	}
	@Override
	public boolean cancelSentRequest(int userIdSender, int userIdreceiver) throws UserDetailsNotFoundException {
		userDao.findById(userIdSender).orElseThrow(()->
		new UserDetailsNotFoundException("sender user details not found"));
		userDao.findById(userIdreceiver).orElseThrow(()->
		new UserDetailsNotFoundException("receiver user details not found"));
		sentRequestDao.cancelRequestSent(userIdSender, userIdreceiver);
		friendRequestDao.removeReceivedRequest(userIdSender, userIdreceiver);
		return true;
	}
	@Override
	public boolean acceptFriendRequest(int userIdSender,int userIdreceiver) throws UserDetailsNotFoundException {
		userDao.findById(userIdSender).orElseThrow(()->
		new UserDetailsNotFoundException("sender user details not found"));
		userDao.findById(userIdreceiver).orElseThrow(()->
		new UserDetailsNotFoundException("receiver user details not found"));
		friendListDao.save(new FriendList(userIdSender,new User(userIdreceiver)));
		friendListDao.save(new FriendList(userIdreceiver,new User(userIdSender)));
		return true;
	}
	@Override
	public boolean sendFriendRequest(int userIdSender, int userIdreceiver) throws UserDetailsNotFoundException, SameUserIdException, RequestAlreadySentException {
		FriendRequest friendRequest = new FriendRequest();
		
		User userS = getUserDetails(userIdSender);
		User userR= getUserDetails(userIdreceiver);
		if(userIdSender!=userIdreceiver) {
			sentRequestDao.save(new SentRequest(userIdSender,new User(userIdreceiver)));
			friendRequestDao.save(new FriendRequest(userIdSender,new User(userIdreceiver)));
		}else throw new SameUserIdException("you can't send request to yourself dummy");
		return true;
		}
	@Override
	public List<User> getFriendsList(int userId) {
	return userDao.getfriendsDetails(userId);
	}
	@Override
	public List<User> getFriendRequests(int userIdreceiver) throws UserDetailsNotFoundException {
		userDao.findById(userIdreceiver).orElseThrow(()->
		new UserDetailsNotFoundException("user id of receiver not found"));
		return userDao.getfriendRequests(userIdreceiver);
	}
	@Override
	public boolean sendMessage(int userIdSender, int userIdreceiver, String message) {
		Date time = new Date();
		System.out.println(time);
		messageDao.save(new Messages(userIdSender, userIdreceiver, time.toString(), message));
		return true;
	}
	@Override
	public List<Messages> getSentMessages(int userIdSender) throws UserDetailsNotFoundException {
		userDao.findById(userIdSender).orElseThrow(()->
		new UserDetailsNotFoundException("sender user details not found"));
		return messageDao.getSentMessage(userIdSender);
	}
	@Override
	public List<Messages> getReceivedMessages(int userIdreceiver) throws UserDetailsNotFoundException {
		userDao.findById(userIdreceiver).orElseThrow(()->
		new UserDetailsNotFoundException("user id of receiver not found"));
		return messageDao.getReceivedMessage(userIdreceiver);
	}
	/*public User getReceiverOfMessage(int userIdreceiver) {
		userDao.getMessageReceiver(userIdreceiver);
		return null;
	}*/
	
	
}