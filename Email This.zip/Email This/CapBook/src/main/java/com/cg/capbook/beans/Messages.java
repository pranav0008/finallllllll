package com.cg.capbook.beans;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="userMessages")
@SequenceGenerator(name="seq5", initialValue=1, allocationSize=1)
public class Messages {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq5")
	private int id5;
	
	private int userIdSender;
	private int userIdreceiver;
	private String messageDate;
	private String message;
	@ManyToOne
	@JoinColumn(name="userId")
	private User user;
	
	@Override
	public String toString() {
		return "Messages [id5=" + id5 + ", userIdSender=" + userIdSender + ", userIdreceiver=" + userIdreceiver
				+ ", messageDate=" + messageDate + ", message=" + message + "]";
	}



	public int getId5() {
		return id5;
	}



	public void setId5(int id5) {
		this.id5 = id5;
	}



	public int getUserIdSender() {
		return userIdSender;
	}



	public void setUserIdSender(int userIdSender) {
		this.userIdSender = userIdSender;
	}



	public int getUserIdreceiver() {
		return userIdreceiver;
	}



	public void setUserIdreceiver(int userIdreceiver) {
		this.userIdreceiver = userIdreceiver;
	}



	public String getMessageDate() {
		return messageDate;
	}



	public void setMessageDate(String messageDate) {
		this.messageDate = messageDate;
	}



	public String getMessage() {
		return message;
	}



	public void setMessage(String message) {
		this.message = message;
	}



	public Messages(int userIdSender, int userIdreceiver, String messageDate, String message) {
		super();
		this.userIdSender = userIdSender;
		this.userIdreceiver = userIdreceiver;
		this.messageDate = messageDate;
		this.message = message;
	}



	public Messages() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
